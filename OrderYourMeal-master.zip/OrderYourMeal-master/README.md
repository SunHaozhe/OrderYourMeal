# OrderYourMeal
Prototype for an ordering system of restaurants
<br>
Human–Computer Interaction team project
